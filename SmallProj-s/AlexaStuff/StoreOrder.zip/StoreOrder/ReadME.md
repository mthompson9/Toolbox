HOW TO MAKE CHANGES/MAINTAIN 
    - The code in the index.js file is commented quite thoroughly.
    - If anything isnt clear you can contact me at my email and I don't mind helping out: mthompson.dev.work@gmail.com

HOW DO I GET MY OWN CREDENTIALS AND GOOGLE SHEET
    - First off you will need to create a new google sheet at: https://docs.google.com/spreadsheets/u/0/
    - Read through and follow the Documentation at: https://developers.google.com/sheets/api/quickstart/nodejs
    - This will contain all of the info you need for basic functions

WHERE IS THE SHEET?
    - https://docs.google.com/spreadsheets/d/1L1j7XQpwS8jmyZ4HNX41rtMyu56WjhrXNQ2-1bEPWk4/edit?usp=sharing