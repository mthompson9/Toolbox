const fs = require('fs');
const readline = require('readline');
const {google} = require('googleapis');
const SCOPES = ['https://www.googleapis.com/auth/spreadsheets'];
const TOKEN_PATH = 'credentials.json';      //MY CREDENTIALS BUT FEEL FREE TO CONTINUE USE  
var addToOrder = {};
var completed = false;
var addToOrder = {
                            "QTY": '',
                            "SIZE": '',
                            "ITEM": ''
                        }


exports.handler = (event, context, callback) => {
    // TODO implement
    try {
        if (event.session.new) {
            //New Session
            console.log('NEW SESSION')
        }
        switch (event.request.type) {
            case "LaunchRequest":
                console.log('LAUNCH REQUEST')
                context.succeed(
                    generateResponse(
                        buildSpeechletResponse(`Welcome to my test skill. Please give me a search term to lookup`, true),
                        {}
                    )
                )
                break;
            case "IntentRequest":
                console.log("INTENT REQUEST")
                //What to do when we get an intent
                
                
                switch (event.request.intent.name) {
                    case "add":
                        try {
                        addToOrder = {
                            "QTY": event.request.intent.slots.QTY.value,
                            "SIZE": event.request.intent.slots.SIZE.value,
                            "ITEM": event.request.intent.slots.ITEM.value
                        }
                        console.log(addToOrder)
                    // Load client secrets from a local file.
                    fs.readFile('client_secret.json', (err, content) => {
                    if (err) return console.log('Error loading client secret file:', err);
                    // Authorize a client with credentials, then call the Google Sheets API.
                    authorize(JSON.parse(content), listMajors)
                    });

                    /**
                    * Create an OAuth2 client with the given credentials, and then execute the
                    * given callback function.
                    * @param {Object} credentials The authorization client credentials.
                    * @param {function} callback The callback to call with the authorized client.
                    */
                    setTimeout(function() {
                    var str = `All done for you. I've added, ` +  addToOrder.QTY + ` ` + addToOrder.SIZE + ` ` +  addToOrder.ITEM
                        console.log('waited 4 seconds')
                        if(completed) {
                        context.succeed(
                            generateResponse(
                                buildSpeechletResponse('Completion response', str, true),
                                buildSpeechletResponse('Completion response', str, true)
                                
                                )
                                )
                        } else {
                            var str = `Sorry I couldn't complete your reuqest to add, ` +  addToOrder.QTY + ` ` + addToOrder.SIZE + ` ` +  addToOrder.ITEM
                            str = 
                            context.succeed(
                                generateResponse(
                                    buildSpeechletResponse('Request Failed', str, true ), 
                                    buildSpeechletResponse('Request Failed', str, true)
                                    )
                                    )
                        }
                    }, 2000);
                        }
                        catch(error) {
                            console.log('There was an error: ' + error)
                        }
                        break;
                
            case "SessionEndedRequest":
                console.log("SESSION END REQUEST")
                break;

            default:
                context.fail(`INVALID REQUEST TYPE: ${event.request.type}`)
        }

    }
    }
    catch(error) { context.fail(`Exception: ${error}`) }

};

//HELPERS
function buildSpeechletResponse (title, outputText, shouldEndSession) {
    return {
        outputSpeech: {
            type: 'PlainText',
            text: outputText
        },
        card: {
            type: 'Simple',
            title: `sessionSpeechlet - ${title}`,
            content: `sessionSpeechlet - ${outputText}`
        },
        reprompt: {
            outputSpeech: {
                type: 'PlainText',
                text: outputText,
            }},
        shouldEndSession,
    }
}

function generateResponse (sessionAttributes, speechletResponse) {
    return {
        version: '1.0',
        sessionAttributes: sessionAttributes,
        response: speechletResponse
    }
}

//Sheets API setup code
function getNewToken(oAuth2Client, callback) {
    const authUrl = oAuth2Client.generateAuthUrl({
        access_type: 'offline',
        scope: SCOPES,
    });
    console.log('Authorize this app by visiting this url:', authUrl);
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
    });
    rl.question('Enter the code from that page here: ', (code) => {
        rl.close();
        oAuth2Client.getToken(code, (err, token) => {
            if (err) return callback(err);
            oAuth2Client.setCredentials(token);
            // Store the token to disk for later program executions
            fs.writeFile(TOKEN_PATH, JSON.stringify(token), (err) => {
                if (err) console.error(err);
                console.log('Token stored to', TOKEN_PATH);
            });
            callback(oAuth2Client);
        });
    });
}


function authorize(credentials, callback) {
    const {client_secret, client_id, redirect_uris} = credentials.installed;
    const oAuth2Client = new google.auth.OAuth2(
    client_id, client_secret, redirect_uris[0]);
    
    // Check if we have previously stored a token.
    fs.readFile(TOKEN_PATH, (err, token) => {
        if (err) return getNewToken(oAuth2Client, callback);
        oAuth2Client.setCredentials(JSON.parse(token));
        callback(oAuth2Client);
        });
    }
    


//My functions for sheets


//Loads the google sheet into the tool. 
function listMajors(auth) {
    const sheets = google.sheets({version: 'v4', auth});
    var count = 0;
    var currVal;
    var storeMatches = []; 
    var userReq = addToOrder;
    var lastRow = 0;
    sheets.spreadsheets.values.get({
        spreadsheetId: '1L1j7XQpwS8jmyZ4HNX41rtMyu56WjhrXNQ2-1bEPWk4',
        range: 'Sheet1!A15:E',
        }, 
        (err, {data}) => {
        if (err) return console.log('The API returned an error: ' + err);
        const rows = data.values;
        if (rows.length) {
            console.log('Category, Item, Pack Size, Cost, Packs required:');
            // Print columns A and E, which correspond to indices 0 and 4.
            console.log(userReq.ITEM)
            rows.map((row) => {
            // console.log(`${row[0]}, ${row[1]}, ${row[2]}, ${row[3]}, ${row[4]}`);  //debug

            if (row[1].toLowerCase().search(userReq.ITEM) != -1){
                // console.log(`${row}`)      //debug
                storeMatches.push(row)
                var currVal = parseInt(row[4])
                lastRow = count; 
            } 
            count = count + 1
            });
            console.log('Matching rows: ')
            console.log(storeMatches)
            addItemFromList(auth, storeMatches, userReq, lastRow)
            
        } else {
            console.log('No data found.');  
        }
    });
}


function addItemFromList(auth, matchingRows, userReq, posMinus15){
    console.log('adding item')
    const pos = posMinus15 + 15
    var newQTY = userReq.QTY
    console.log(newQTY)
    const sheets = google.sheets({version: 'v4', auth})
    var iter = 0;
    //Find out how many rows match the request.
    if (matchingRows.length == 1){
        console.log('about to make the finall call')
        newQTY = parseInt(newQTY)
        newQTY = newQTY + parseInt(matchingRows[0][4])
        console.log(newQTY)
        sheetsCall(auth, pos, newQTY)
        completed = true;
    } else if (matchingRows.length > 1){
        matchingRows.map((row) => {
            iter = iter + 1;
            if (row[1].toLowerCase().search(userReq.SIZE) != -1 && row[1].toLowerCase().search('extra ' + userReq.SIZE) == -1 ){
                console.log("Matching Row: " + row)
                iter = pos - (matchingRows.length - iter)
                newQTY = ((parseInt(newQTY)) + parseInt(row[4]))
                
                console.log('just before final call')
                sheetsCall(auth, iter, newQTY)
                completed = true;
            } 
        })
    } else {
        completed = false
    }  
}



//function to update the sheet with the current requested item
function sheetsCall(auth, rowNum, QTY ){
    console.log('line 181')
    const sheets = google.sheets({version: 'v4', auth})
    var params = { 
        auth: auth,
        spreadsheetId: '1L1j7XQpwS8jmyZ4HNX41rtMyu56WjhrXNQ2-1bEPWk4',
        range: 'E' + rowNum,
        valueInputOption: 'RAW',
        resource: {
            values: [
                [QTY]
            ],
        },
    }
    //MAKE THE CALL TO THE SHEETS UP AND UPDATE
    const str = ("Done", "All done for you. I've added, " + addToOrder.QTY + " " + addToOrder.SIZE + " " + addToOrder.ITEM);
    sheets.spreadsheets.values.update(params)
      completed = true;
    console.log('righ here homie')
}
