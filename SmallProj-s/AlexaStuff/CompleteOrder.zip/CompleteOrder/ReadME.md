HOW DO I CHANGE THE RECIPIENT EMAIL 
    - See the code comments. 
    - Line 14 of index.js contains the recipeient email. The line around tis are setting up the email functionality called "nodeMailer"

THE FIRST TIME I RAN THE CODE AFTER UPDATING IT DIDNT SEND THE EMAIL?
    - No problem, this is due to the way Google's authentication works. 
    - Run it again. 
    - If it doesn't work after the second time, roll back your code and try to see what went wrong in your change.

WHERE CAN I SEE THE SPREADSHEET 
     - Please see the readme for the store order function.
     - https://docs.google.com/spreadsheets/d/1L1j7XQpwS8jmyZ4HNX41rtMyu56WjhrXNQ2-1bEPWk4/edit?usp=sharing