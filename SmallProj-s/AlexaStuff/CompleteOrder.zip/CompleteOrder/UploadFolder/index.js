const fs = require('fs');
const readline = require('readline');
const {google} = require('googleapis');
const SCOPES = ['https://www.googleapis.com/auth/spreadsheets'];
const TOKEN_PATH = 'credentials.json';      //MY CREDENTIALS BUT FEEL FREE TO CONTINUE USE  
var addToOrder = {};
var completed = false;
var addToOrder = {
                            "BuildingNo": ''
    };
                        
// VARIABLES FOR THE NODEMAILER
const nodemailer = require('nodemailer');
const mailingList = 'matthew.plane@syngenta.com' //this is a temp email, change it to the target email when tests are successful
const piEmail = 'templogger9@gmail.com';            //Credentials for an email we made for experiments in the lab. Not personal data linked to the account.
const emailPassword = 'ThinkBig';
const transporter = nodemailer.createTransport('smtps://' + piEmail + ':' + emailPassword + '@smtp.gmail.com');         //smtp transporter used to send mail in nodemailer. 


exports.handler = (event, context, callback) => {
    // TODO implement
    try {
        if (event.session.new) {
            //New Session
            console.log('NEW SESSION')
        }
        switch (event.request.type) {
            case "LaunchRequest":
                console.log('LAUNCH REQUEST')
                context.succeed(
                    generateResponse({},
                        buildSpeechletResponse(`Welcome to my test skill. Please give me a search term to lookup`, true), 
                    )
                )
                break;
            case "IntentRequest":
                console.log("INTENT REQUEST")
                //What to do when we get an intent
                switch (event.request.intent.name) {
                    case "sendOrder":
                        try {
                            var destination  = event.request.intent.slots.location.value
                            if (destination.includes('slash')) {
                                destination = destination.replace(' slash ', '/')
                                console.log('Destination: ' + destination)
                            }
                            addToOrder = {
                                "BuildingNo": destination,
                            }
                            console.log(addToOrder)
                        // Load client secrets from a local file.
                        fs.readFile('client_secret.json', (err, content) => {
                            if (err) return console.log('Error loading client secret file:', err);
                            // Authorize a client with credentials, then call the Google Sheets API.
                            authorize(JSON.parse(content), listMajors)
                        });
                        /**
                        * Create an OAuth2 client with the given credentials, and then execute the
                        * given callback function.
                        * @param {Object} credentials The authorization client credentials.
                        * @param {function} callback The callback to call with the authorized client.
                        */

                        //Really hacky way to work around async issues. 
                        setTimeout(function() {
                            var str = `All done for you. I've added location, ` +  addToOrder.BuildingNo
                            console.log('waited 4 seconds')
                            if(completed) {
                                context.succeed(
                                    generateResponse(
                                        {},
                                        buildSpeechletResponse('Completion response', str, true)
                                    )
                                )
                            } else {
                                var str = `Sorry I couldn't complete your reuqest to add, ` +  addToOrder.BuildingNo
                                context.succeed(
                                    generateResponse(
                                        {}, 
                                        buildSpeechletResponse('Request Failed', str, true)
                                    )
                                )
                            }
                        }, 2000);
                        }
                        catch(error) {
                            console.log('There was an error: ' + error)
                        }
                        break;
                    case "SessionEndedRequest":
                        console.log("SESSION END REQUEST")
                        break;

                    default:
                        context.fail(`INVALID REQUEST TYPE: ${event.request.type}`)
            }
        }
    }
    catch(error) { context.fail(`Exception: ${error}`) }
};

//HELPERS
function buildSpeechletResponse (title, outputText, shouldEndSession) {
    return {
        outputSpeech: {
            type: 'PlainText',
            text: outputText
        },
        card: {
            type: 'Simple',
            title: `sessionSpeechlet - ${title}`,
            content: `sessionSpeechlet - ${outputText}`
        },
        reprompt: {
            outputSpeech: {
                type: 'PlainText',
                text: outputText,
            }},
        shouldEndSession,
    }
}

function generateResponse (sessionAttributes, speechletResponse) {
    return {
        version: '1.0',
        sessionAttributes: sessionAttributes,
        response: speechletResponse
    }
}

//Sheets API setup code
function getNewToken(oAuth2Client, callback) {
    const authUrl = oAuth2Client.generateAuthUrl({
        access_type: 'offline',
        scope: SCOPES,
    });
    console.log('Authorize this app by visiting this url:', authUrl);
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
    });
    rl.question('Enter the code from that page here: ', (code) => {
        rl.close();
        oAuth2Client.getToken(code, (err, token) => {
            if (err) return callback(err);
            oAuth2Client.setCredentials(token);
            // Store the token to disk for later program executions
            fs.writeFile(TOKEN_PATH, JSON.stringify(token), (err) => {
                if (err) console.error(err);
                console.log('Token stored to', TOKEN_PATH);
            });
            callback(oAuth2Client);
        });
    });
}

//authorisation stuff for sheets/google
function authorize(credentials, callback) {
    const {client_secret, client_id, redirect_uris} = credentials.installed;
    const oAuth2Client = new google.auth.OAuth2(
    client_id, client_secret, redirect_uris[0]);
    // Check if we have previously stored a token.
    fs.readFile(TOKEN_PATH, (err, token) => {
        if (err) return getNewToken(oAuth2Client, callback);
        oAuth2Client.setCredentials(JSON.parse(token));
        callback(oAuth2Client);
    });
}
    


//My functions for sheets

//Not really necessary anymore. 
function listMajors(auth) {
    const sheets = google.sheets({version: 'v4', auth});
    var count = 0;
    var currVal;
    var storeMatches = []; 
    var userReq = addToOrder.BuildingNo;
    var lastRow = 0;
    
    console.log(storeMatches)
    addItemFromList(auth, userReq)

}


//again not needed. Just using as a call for sheetsCall function
function addItemFromList(auth, userReq){
    const sheets = google.sheets({version: 'v4', auth})
    //Find out how many rows match the request.
    sheetsCall(auth, userReq)
}

//update the sheet with the reuested delivery address 
function sheetsCall(auth, BuildingNo ){
    console.log('line 181')
    const sheets = google.sheets({version: 'v4', auth})
    var params = { 
        auth: auth,
        spreadsheetId: '1L1j7XQpwS8jmyZ4HNX41rtMyu56WjhrXNQ2-1bEPWk4',
        range: 'B8',
        valueInputOption: 'RAW',
        resource: {
            values: [
                [BuildingNo]
            ],
        },
    }
    //Create a new blank sheet to copy contents of the order form to.
    const str = ("Done", "All done for you. I've added the location " + BuildingNo);
    sheets.spreadsheets.values.update(params)
      completed = true;
    console.log('righ here homie')
    createBlank(auth, params.spreadsheetId)
}

//Grab the new sheets ID and call the function to copy the sheet 
function createBlank(auth, existingID) { //can be cleaned up by making sheets.spreadsheets.create a callback for copyTo
    const sheets = google.sheets({version: 'v4', auth})
    var request = { 
        //specifiy any params you want here
    };
    var newSheetID = '';
    newSheetID = sheets.spreadsheets.create(request, function(err, response){
        if (err) {
            console.log(err)
            console.log('There was an error ^^^^');
            return
        } else {
            newSheetID = JSON.stringify(response.data.spreadsheetId, null, 2)
            // console.log(response) //DEBUG 
            const tryingSomething = response.data.spreadsheetId
            console.log('NEW SHEET CREATED: ' + newSheetID)
            console.log('DONE LINE 245')
        }
        console.log('247:  ' + newSheetID)
        copySheet(auth, newSheetID)
    })
}

//Copy the contents of the original order form and send it over to our new blank sheet - This needs a call back to 0 every value in the original sheet. 
function copySheet(auth, ID){
    const sheets = google.sheets({version: 'v4', auth})
    const newID = ID.substring(1, ID.length-1)
    var request2 = { 
        //You need to fill these params with some field, I've left blank ones in also
        spreadsheetId: '1L1j7XQpwS8jmyZ4HNX41rtMyu56WjhrXNQ2-1bEPWk4',  // TODO: Update placeholder value.
        // The ID of the sheet to copy.
        sheetId: 0,  // TODO: Update placeholder value.
        resource: {
          // The ID of the spreadsheet to copy the sheet to.
          destinationSpreadsheetId: newID,  // TODO: Update placeholder value.
          // TODO: Add desired properties to the request body.
        },
        auth: auth,
    };
    console.log('line 268 ' + request2.resource.destinationSpreadsheetId)
    sheets.spreadsheets.sheets.copyTo(request2, function(err, response){
        if (err) { 
            console.log('There was an error: ' + err)
        };
        if (response) {
            console.log('apparenlty it worked')
            return;
        }
    })
    sendLink(newID)
}



//Send the Link for the order form to the speicifed email addr.
function sendLink(ID){
    console.log('sendLink Started')
    var  mailOptions = {
       from: piEmail,
       to: mailingList,
       subject: 'Alexa Chemistry Store order',
       text:  'Hi, our latest order form is complete. Please find it availble for download or printout on the second sheet, "Copysheet1", at: ' + 'https://docs.google.com/spreadsheets/d/' + ID + '/edit#gid=0'  // plaintext body
    };
    console.log('mail Options: ' + JSON.stringify(mailOptions))
    return transporter.sendMail(mailOptions, function(err, info){ 
        if (err) { 
             console.log(err)
        } else {
             console.log('Message Sent: ' + info.response)
        }
        console.log('finished')
    })
}