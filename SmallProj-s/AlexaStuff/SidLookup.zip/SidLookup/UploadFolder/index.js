var https = require('https');
var request = require('request'); 
var cheerio = require('cheerio');


exports.handler = (event, context, callback) => {
    // TODO implement
    try {
        if (event.session.new) {
            //New Session
            console.log('NEW SESSION')
        }
        switch (event.request.type) {
            case "LaunchRequest":
                console.log('LAUNCH REQUEST')
                context.succeed(
                    generateResponse(
                        buildSpeechletResponse("Welcome to my test skill. Please give me a search term to lookup", true),
                        {}
                    )
                )
                break;
            case "IntentRequest":
                console.log("INTENT REQUEST")
                //What to do when we get an intent
                switch (event.request.intent.name) {
                    case "WikiHitCount":
                        console.log('WIKI HIT COUNT STARTED')
                        var searchTerm = event.request.intent.slots.SearchTerm.value
                        var endpoint = 'https://en.wikipedia.org/w/api.php?action=query&format=json&list=search&utf8=1&srsearch='
                        var termArr = searchTerm.split(' ')
                        termArr.forEach( term => {
                            endpoint = endpoint + (term + '+')
                         })
                        var body =''
                        https.get(endpoint, (response) => {
                            response.on('data', (chunk) => {body += chunk })
                            response.on('end', () => {
                                var data = JSON.parse(body)
                                var hitCount = data.query.searchinfo.totalhits
                                context.succeed(
                                    generateResponse(
                                        buildSpeechletResponse(searchTerm + ` has ${hitCount} Wikipedia hits`,true),
                                        {}
                                        )
                            )
                        })
                        })
                        break;
                        
                    case "sid":
                        console.log('Sid started')
                        try {
                            console.log('INTENT FOR SID HAS STARTED')
                            var searchTerm = event.request.intent.slots.compound.value;
                            var oldTerm;
                            if (searchTerm.search(' ') != -1){
                                oldTerm = searchTerm
                                searchTerm = searchTerm.replace(/ /g, '_')
                            } else {
                                oldTerm = searchTerm
                            }
                            console.log(searchTerm)
                            var URL = 'https://en.wikipedia.org/wiki/' + searchTerm;            //GRAB THE SEARCH PHRASE AND APPEND IT TO THE END OF THE LINK FOR THE WIKI
                            // console.log(URL)            //DEBUG
                            request(URL, function(error, response, html){           //START OF CHEERIO STUFF
                                console.log('REQUEST MADE');
                                try {           //USING TRY CATCH FOR CLEANER ERROR HANDLING
                                    // console.log( 'trying to use cheerio to load page now')          //DEBUG
                                    if (html){
                                    var $ = cheerio.load(html);
                                    console.log('PAGE LOADED');
                                    var infobox = $('table.infobox').children('tbody');             //LOOK IN TABLE TAGS FOR A CLASSNAME OF INFOBOX
                                        infobox.children().each(function(i, element){           //FOR EACH CHILD IN THE INFOBOX DO {}
                                            var row = $(this);
                                            if(row.children().first().children().first().text() == 'GHS hazard statements') {           //FIND HCODES SECTION AT OUR CURRENT LOCATION
                                                var hCodes = row.first().first().text().toString();
                                                var pPhrases = row.first().next().text().toString();
                                                hCodes = resultCleanup(hCodes);
                                                pPhrases = resultCleanup(pPhrases);
                                                var outputStr = `I found the following for  ` + oldTerm + `; ` +  hCodes + ` ` + pPhrases
                                                context.succeed(
                                                generateResponse({},
                                                    (buildSpeechletResponse(searchTerm ,outputStr , true))
                                                    )
                                                    )
                                            }
                                        })
                                        console.log('IT WAS CAKE 🍰')
                                        var outputStr = `Hmm. Unfortunately there don't seem to be any safety codes surrounding  ` + oldTerm + `. Please try again.`
                                            context.succeed(
                                                generateResponse({},
                                                    (buildSpeechletResponse(searchTerm ,outputStr , true))
                                                    )
                                                    )
                                } else {
                                        console.log('There was no HTML loaded. Please try again')
                                    }
                                }catch(error){
                                    console.log(error)
                                    console.log('THERE WAS AN ERROR PLEASE TRY AGAIN')
                                }
                                 
                            })
                        }
                        catch(error) { 
                            console.log('There was an error. Please try again')
                        } 
                
                
            case "SessionEndedRequest":
                console.log("SESSION END REQUEST")
                break;

            default:
                context.fail(`INVALID REQUEST TYPE: ${event.request.type}`)
        }

    }
    }
    catch(error) { context.fail(`Exception: ${error}`) }

};

//RESULT CLEANUP
function resultCleanup (wubalubadubdub) {
    var newWub = wubalubadubdub.replace(/\n/g, '');
    var finalWub = newWub.replace('statements', 'statements, ')
    finalWub = finalWub.concat('.')
    
    return finalWub
} 


//HELPERS
function buildSpeechletResponse (title, outputText, shouldEndSession) {
    return {
        outputSpeech: {
            type: 'PlainText',
            text: outputText
        },
        card: {
            type: 'Simple',
            title: `sessionSpeechlet - ${title}`,
            content: `sessionSpeechlet - ${outputText}`
        },
        reprompt: {
            outputSpeech: {
                type: 'PlainText',
                text: outputText,
            }},
        shouldEndSession,
    }
}

function generateResponse (sessionAttributes, speechletResponse) {
    return {
        version: '1.0',
        sessionAttributes: sessionAttributes,
        response: speechletResponse
    }
}

                        