

HOW TO MAKE CHANGES/MAINTAIN 
    - The code in the index.js file is commented quite thoroughly.
    - If anything isnt clear you can contact me at my email and I don't mind helping out: mthompson.dev.work@gmail.com

TO UPDATE THE CHEMICALS WE CAN LOOK UP: 
    - You have to update the types.chemcompound object in the interactionModel.json file
    - object structure it :
        {
            "name": {
                "value": "calcium"
            }
        },


